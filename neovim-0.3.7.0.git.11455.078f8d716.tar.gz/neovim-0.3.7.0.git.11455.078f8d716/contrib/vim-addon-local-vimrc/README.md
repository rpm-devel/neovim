# vim-addon-local-vimrc

## Installation

### Step 1

Install [vim-addon-local-vimrc](https://github.com/MarcWeber/vim-addon-local-vimrc).
For example with [Vundle](https://github.com/MarcWeber/vim-addon-local-vimrc):
```vim
Bundle 'MarcWeber/vim-addon-local-vimrc'
```

### Step 2

```bash
cp vimrc ../../.vimrc
echo .vimrc >> ../../.git/info/exclude
```
