#ifndef NVIM_OS_TTY_H
#define NVIM_OS_TTY_H

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "os/tty.h.generated.h"
#endif
#endif  // NVIM_OS_TTY_H
