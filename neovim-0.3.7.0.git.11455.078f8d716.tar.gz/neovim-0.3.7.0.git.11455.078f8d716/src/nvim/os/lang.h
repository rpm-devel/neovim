#ifndef NVIM_OS_LANG_H
#define NVIM_OS_LANG_H

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "os/lang.h.generated.h"
#endif
#endif  // NVIM_OS_LANG_H
