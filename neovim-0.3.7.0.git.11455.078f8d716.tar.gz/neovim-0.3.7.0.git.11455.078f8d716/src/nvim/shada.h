#ifndef NVIM_SHADA_H
#define NVIM_SHADA_H

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "shada.h.generated.h"
#endif
#endif  // NVIM_SHADA_H
