#ifndef NVIM_UI_COMPOSITOR_H
#define NVIM_UI_COMPOSITOR_H

#include "nvim/ui.h"
#include "nvim/event/defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "ui_compositor.h.generated.h"
#endif
#endif  // NVIM_UI_COMPOSITOR_H
