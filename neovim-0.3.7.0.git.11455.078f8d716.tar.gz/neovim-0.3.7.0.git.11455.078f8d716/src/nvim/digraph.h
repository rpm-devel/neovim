#ifndef NVIM_DIGRAPH_H
#define NVIM_DIGRAPH_H

#include "nvim/types.h"
#include "nvim/ex_cmds_defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "digraph.h.generated.h"
#endif
#endif  // NVIM_DIGRAPH_H
