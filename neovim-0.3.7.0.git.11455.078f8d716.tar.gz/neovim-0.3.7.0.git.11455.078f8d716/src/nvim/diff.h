#ifndef NVIM_DIFF_H
#define NVIM_DIFF_H

#include "nvim/pos.h"
#include "nvim/ex_cmds_defs.h"

#ifdef INCLUDE_GENERATED_DECLARATIONS
# include "diff.h.generated.h"
#endif
#endif  // NVIM_DIFF_H
